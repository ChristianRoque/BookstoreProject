import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface BookRepo extends MongoRepository<com.Group13.BookstoreProject.models.Bookgenre,String> {


    @Query("{'isbn' : ?0}")
    com.Group13.BookstoreProject.models.Bookgenre searchBookByisbnRepo(String i);


    @Query("{'authorName' : ?0}")
    List<com.Group13.BookstoreProject.models.Bookgenre> searchBookByAuthorRepo(String a);

    // @Query("{'title' : ?0}")


    @Query("{'genre' : ?0}")
    List<com.Group13.BookstoreProject.models.Bookgenre> searchBookByGenre(String g);


}

