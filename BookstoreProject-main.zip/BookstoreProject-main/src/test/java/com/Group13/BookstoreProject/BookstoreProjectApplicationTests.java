package com.Group13.BookstoreProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
