package com.Group13.BookstoreProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoreProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookstoreProjectApplication.class, args);
		System.out.println("I'm connected.");
	}
}