package com.Group13.BookstoreProject.repositories;
import com.Group13.BookstoreProject.models.Book;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface BookRepo extends MongoRepository<Book,String> {


    @Query("{'isbn' : ?0}")
    Book searchBookByisbnRepo(String i);


    @Query("{'authorName' : ?0}")
    List<Book> searchBookByAuthorRepo(String a);

    // @Query("{'title' : ?0}")


    @Query("{'genre' : ?0}")
    List<Book> searchBookByGenre(String g);


}
